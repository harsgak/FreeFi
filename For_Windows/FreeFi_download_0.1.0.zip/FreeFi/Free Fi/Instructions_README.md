#FreeFi
.

###First time Setting up

* Right click on **FreeFi.exe** and click "run as administrator".
* Follow instructions on screen to set wifi *name* and *password*.

* In lan/ethernet settings turn on internet sharing for ethernet/your internet source network.

###REGULAR USE
* Right click on  **adhoc_on_off.exe** and click "run as administrator."

```>NOTE:"Run as administrator" is important^```

#####About  '*adhoc_on_off.exe*
* It is a toggle (on/off) switch. 
* If hotspot is currently ***on*** it will turn wifi sharing(hotspot) ***off***.
* If hotspot is currently ***off*** it will turn wifi sharing(hotspot) ***on***.



^Tricks:
* Right click on adhoc_on_off.exe and in properties goto compatibility tab.
* Make sure that "run this program as an administrator" is ticked.
* Now you can just double click to run adhoc_on_off.exe properly
