#FreeFi
.
###First time Setting up

* Run **FreeFi.exe** and if UAC window pops up select allow.
* Follow instructions on screen to set wifi *name* and *password*.

* In lan/ethernet settings turn on internet sharing for ethernet/your internet source network.  <IMPORTANT>

###REGULAR USE
* Use **Hotspot_on_off.exe** as on/off switch.

#####About  '*Hotspot_on_off.exe*
* It is a toggle (on/off) switch. 
* If hotspot is currently ***on*** it will turn wifi sharing(hotspot) ***off***.
* If hotspot is currently ***off*** it will turn wifi sharing(hotspot) ***on***.



^Tricks:
Pin it to the taskbar for one click access.
